A - Attack (must have at least 1 to attack)
F - Fill up a street lamp (5 fireflies)

Player can move to town map by going right. 
Going left moves the player back to the tutorial state. 

There are a few console.log commands that lets the player know if there's no more 
dialogue and status of streetlamp when pressing F. 